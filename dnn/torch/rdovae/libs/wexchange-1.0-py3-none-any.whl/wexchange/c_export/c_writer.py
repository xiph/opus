import os

class CWriter:
    def __init__(self, filename_withough_extension, message=None, header_only=False):
        
        
        self.header_only = header_only
        self.header = open(filename_withough_extension + ".h", "w")
        header_name = os.path.basename(filename_withough_extension) + '.h'
        
        if message is not None:
            self.header.write(f"/* {message} */\n\n")
            
        self.header_guard = "_" + os.path.basename(filename_withough_extension).upper() + "_H_"
        self.header.write(
f"""
#ifndef {self.header_guard}
#define {self.header_guard}

"""
        )
        
        if not self.header_only:
            self.source = open(filename_withough_extension + ".c", "w")
            if message is not None:
                self.source.write(f"/* {message} */\n\n")
            
            self.source.write(f'#include "{header_name}"\n\n')
            
        
    def close(self):
        self.header.write(f"\n#endif /* {self.header_guard} */\n")
        if not self.header_only:
            self.source.close()
            
        self.header.close()
        
    def __del__(self):
        try:
            self.close()
        except:
            pass