from .c_writer import CWriter
from .common import print_gru_layer, print_dense_layer, print_conv1d_layer, print_vector